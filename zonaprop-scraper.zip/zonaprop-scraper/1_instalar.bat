@echo off
echo.
echo ========================================
echo  ZonaProp - Instalando dependencias...
echo ========================================
echo.

pip install -r requirements.txt

if %errorlevel% neq 0 (
    echo.
    echo ERROR: Fallo la instalacion. Asegurate de tener Python instalado.
    pause
    exit /b 1
)

echo.
echo ✅ Instalacion completa!
echo.
pause
