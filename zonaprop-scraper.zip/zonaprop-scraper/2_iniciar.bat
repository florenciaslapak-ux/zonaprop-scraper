@echo off
echo.
echo ========================================
echo  ZonaProp - Iniciando servidor...
echo ========================================
echo.
echo Abriendo http://localhost:5000 en tu navegador...
echo (Cerrá esta ventana para detener el servidor)
echo.

start "" "http://localhost:5000"
python server.py

pause
